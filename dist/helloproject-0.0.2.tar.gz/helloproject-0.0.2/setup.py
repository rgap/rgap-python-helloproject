from setuptools import setup

setup(
    name='helloproject',
    version='0.0.2',
    description='a pip-installable package example',
    license='MIT',
    packages=['helloproject'],
    author='Rel Guzman',
    author_email='rel.guzmanapaza@sydney.edu.au',
    keywords=['example'],
    url='https://github.com/rgap/helloproject'
)