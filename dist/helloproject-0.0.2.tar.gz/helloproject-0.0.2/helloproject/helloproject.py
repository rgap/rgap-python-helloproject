def hello():
    print 'Hello!'

def hellov2():
    print 'Hello_v2!'